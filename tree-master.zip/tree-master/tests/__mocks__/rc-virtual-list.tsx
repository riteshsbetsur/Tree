import List from 'rc-virtual-list/lib/mock';

export default List;
