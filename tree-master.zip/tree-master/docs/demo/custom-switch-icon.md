## custom-switch-icon

<code src="../examples/custom-switch-icon.jsx">
