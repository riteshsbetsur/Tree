## expandAction

<code src="../examples/expandAction.jsx">
