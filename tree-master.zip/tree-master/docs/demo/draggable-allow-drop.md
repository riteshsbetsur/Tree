## draggable-allow-drop

<code src="../examples/draggable-allow-drop.jsx">
