## dynamic

<code src="../examples/dynamic.jsx">
