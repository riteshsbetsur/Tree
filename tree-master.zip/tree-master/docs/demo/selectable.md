## selectable

<code src="../examples/selectable.jsx">
