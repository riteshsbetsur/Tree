## basic-controlled

<code src="../examples/basic-controlled.jsx">
