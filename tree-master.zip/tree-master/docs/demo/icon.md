## icon

<code src="../examples/icon.jsx">
