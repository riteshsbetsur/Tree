## funtionTitle

<code src="../examples/funtionTitle.jsx">
