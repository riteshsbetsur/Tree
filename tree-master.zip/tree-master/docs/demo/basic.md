## basic

<code src="../examples/basic.jsx">
