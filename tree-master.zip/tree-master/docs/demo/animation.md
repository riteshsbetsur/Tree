## animation

<code src="../examples/animation.jsx">
